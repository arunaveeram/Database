﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class FLIGHT_BOOKING : Form
    {
        DBInformation dbi = new DBInformation();
        OleDbConnection con = new OleDbConnection();
        public FLIGHT_BOOKING()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            SEAT_CONFIRM sc = new SEAT_CONFIRM();
            sc.ShowDialog();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = listBox1.SelectedItem.ToString();
            listBox1.Items.Clear();
            listBox1.Items.Add(a);


        }

        private void FLIGHT_BOOKING_Load(object sender, EventArgs e)
        {
            label8.Hide();
            
            dbi.Username = "system";
            dbi.Password = "oracle";
            dbi.Datasource = "orcl";

            string conString = @"Provider=MSDAORA;Data Source=" + dbi.Datasource +
                ";Persist Security Info=True;User ID=" + dbi.Username +
                ";Password=" + dbi.Password;

            con.ConnectionString = conString;

            string sql = "SELECT ARPORT_CITY FROM AIRPORT";

            OleDbDataReader reader;

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    label8.Text= reader["ARPORT_CITY"].ToString();
                    listBox1.Items.Add(label8.Text);
                    listBox2.Items.Add(label8.Text);
                }


                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string a = listBox2.SelectedItem.ToString();
            listBox2.Items.Clear();
            listBox2.Items.Add(a);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            dbi.Username = "system";
            dbi.Password = "oracle";
            dbi.Datasource = "orcl";

            string conString = @"Provider=MSDAORA;Data Source=" + dbi.Datasource +
                ";Persist Security Info=True;User ID=" + dbi.Username +
                ";Password=" + dbi.Password;

            con.ConnectionString = conString;

            string sql = "SELECT FLGT_NO,FLGT_FARE,FLGT_SEATS FROM FLIGHT";

            OleDbDataReader reader;

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    
                    textBox4.Text = reader["FLGT_NO"].ToString();
                    textBox3.Text = reader["FLGT_FARE"].ToString();
                    textBox5.Text = reader["FLGT_SEATS"].ToString();

                }


                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
    }

