﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApplication3
{
    public partial class cusemp : Form
    {
        DBInformation dbi = new DBInformation();
        OleDbConnection con = new OleDbConnection();
        public cusemp()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dbi.Username = "system";
            dbi.Password = "oracle";
            dbi.Datasource = "orcl";

            string conString = @"Provider=MSDAORA;Data Source=" + dbi.Datasource +
                ";Persist Security Info=True;User ID=" + dbi.Username +
                ";Password=" + dbi.Password;

            con.ConnectionString = conString;

            string sql = "SELECT EMP_ID,EMP_NAME,EMP_SSN,EMP_ALLOTED_FOR FROM EMPLOYEE WHERE FLGT_NO='" + textBox1.Text + "'";

            OleDbDataReader reader;

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                reader = cmd.ExecuteReader();
                DataTable dt = new DataTable();

                OleDbDataAdapter da = new OleDbDataAdapter(sql, con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void cusemp_Load(object sender, EventArgs e)
        {

            
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            this.Hide();
            dataGridView1.Show();
        }
    }
}
