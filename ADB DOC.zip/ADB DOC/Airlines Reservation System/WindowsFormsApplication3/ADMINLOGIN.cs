﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class ADMINLOGIN : Form
    {
        DBInformation dbi = new DBInformation();
        OleDbConnection con = new OleDbConnection();
        public ADMINLOGIN()
        {
            InitializeComponent();
        }

        private void ADMINLOGIN_Load(object sender, EventArgs e)
        {
            listBox2.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dbi.Username = "system";
            dbi.Password = "oracle";
            dbi.Datasource = "orcl";

            string conString = @"Provider=MSDAORA;Data Source=" + dbi.Datasource +
                ";Persist Security Info=True;User ID=" + dbi.Username +
                ";Password=" + dbi.Password;

            con.ConnectionString = conString;

            string sql = "SELECT * FROM login where username = '" + textBox1.Text + "' and password='" + textBox2.Text + "'";

            OleDbDataReader reader;

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand(sql, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    textBox1.Visible = true;
                    textBox1.Text = Convert.ToString(reader["username"]);

                    textBox2.Visible = true;
                    textBox2.Text = Convert.ToString(reader["password"]);
                }

                listBox2.Show();
    
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();


        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (listBox2.SelectedIndex)
            {
                case 0:

                    this.Hide();
                    adminarport a = new adminarport();
                    a.ShowDialog();
                    break;

                case 1:

                    this.Hide();
                    AIRLINES a1 = new AIRLINES();
                    a1.ShowDialog();
                    break;
                case 2:

                    this.Hide();
                    ADMINEMP e1 = new ADMINEMP();
                    e1.ShowDialog();
                    break;
                case 3:

                    this.Hide();
                    adminFlight f = new adminFlight();
                    f.ShowDialog();
                    break;

            }
        }
    }
}
